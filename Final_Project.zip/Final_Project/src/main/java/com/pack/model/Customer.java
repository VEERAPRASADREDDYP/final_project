package com.pack.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customerTable")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 int id;
	 public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getAccount_Type() {
		return Account_Type;
	}
	public void setAccount_Type(String account_Type) {
		Account_Type = account_Type;
	}
	public long getCustomerAccNum() {
		return customerAccNum;
	}
	public void setCustomerAccNum(long number1) {
		this.customerAccNum = number1;
	}
	public long getCustomerAccId() {
		return customerAccId;
	}
	public void setCustomerAccId(long number) {
		this.customerAccId = number;
	}
	@Column(name="firstName")
	String firstName;
	@Column(name="lastName")
	 String lastName;
	@Column(name="age")
	 String age;
	@Column(name="gender")
	 String gender;
	@Column(name="occupation")
	 String occupation;
	@Column(name="email")
	 String email;
	@Column(name="salary")
	 int salary;
	@Column(name="Account_Type")
	 String Account_Type;
	@Column(name="customerAccNum")
	 long customerAccNum;
	@Column(name="customerAccId")
	 long customerAccId;
}
