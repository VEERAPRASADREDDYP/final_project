package com.pack.model;

public class Search {
	long customerAccId;

	public long getCustomerAccId() {
		return customerAccId;
	}

	public void setCustomerAccId(long customerAccId) {
		this.customerAccId = customerAccId;
	}
}
