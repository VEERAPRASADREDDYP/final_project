package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.CustomerDao;
import com.pack.model.Customer;

public class CustomerService {
	@Autowired
	private CustomerDao customerDAO;
 



public int addUser(Customer customerBean) {
	// TODO Auto-generated method stub
	return customerDAO.addUser(customerBean);
	
}
		 
		



}
