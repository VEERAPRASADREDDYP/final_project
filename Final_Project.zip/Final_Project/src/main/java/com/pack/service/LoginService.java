package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.dao.LoginDao;
import com.pack.model.Login;

public class LoginService {
	@Autowired
	private LoginDao loginDAO;
 

public int checkLogin(Login userBean) {
	return loginDAO.checkLogin(userBean);
}
		 
		



		/*public void addUser(Login userBean) {
			// TODO Auto-generated method stub
			loginDAO.addUser(userBean);
		}*/
}
