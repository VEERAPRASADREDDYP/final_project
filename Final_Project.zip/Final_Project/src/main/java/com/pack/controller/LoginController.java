package com.pack.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Customer;
import com.pack.model.Login;
import com.pack.model.Modify;
import com.pack.model.Search;
import com.pack.service.CustomerService;
import com.pack.service.LoginService;
@Controller
public class LoginController {
	public long a;
	@Autowired
	private LoginService loginService;
	@Autowired
	private CustomerService customerService;

	
	@RequestMapping("createCustomer")
	public String add(Model m)
	{

		m.addAttribute("customerBean", new Customer());
		return "create";
		
	}
	@RequestMapping("modifyCustomer")
	public String modify(Model m)
	{

		m.addAttribute("searchBean", new Search());
		return "search";
		
	}
	@RequestMapping("modify")
	public ModelAndView modifier(@Valid @ModelAttribute("searchBean")Search searchBean,BindingResult result,Model m)
	{
		
		System.out.println(searchBean.getCustomerAccId());
	 long  a=searchBean.getCustomerAccId();
		//m.addAttribute(searchBean.getCustomerAccId());
		ModelAndView obj=new ModelAndView();
		obj.setViewName("modifier");
		obj.addObject(searchBean);
		//m.addAttribute("modifyBean", new Modify());
		return obj;
		
	}
	@RequestMapping("update")
	public String update(@Valid @ModelAttribute("custBean")Modify custBean,BindingResult result,Model m)
	{
		
 		//int p=customerService.addUser(custBean); 
 		System.out.println(custBean.getFirstName());
 	
 		return "updated";
		
		
	
	}
	
	@RequestMapping("/proceed")
	public ModelAndView create(@Valid @ModelAttribute("customerBean")Customer customerBean,BindingResult result,Model m)
	{
		long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
		 customerBean.setCustomerAccId(number);
		 long number1 = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
		customerBean.setCustomerAccNum(number1);
		 m.addAttribute("user", customerBean);
 		int p=customerService.addUser(customerBean); 
 		System.out.println(customerBean.getCustomerAccId());
 		ModelAndView obj=new ModelAndView();
		obj.setViewName("final");
		obj.addObject("num",customerBean);
 		
 		return obj;
		
		
	
	}
	@RequestMapping("/clear")
	public String adder(Model m)
	{

		m.addAttribute("customerBean", new Customer());
		return "create";
		
	}
	@RequestMapping(value="/log")
	public String log(){
		return "login";
	}

	@RequestMapping(value="/login")
	public String saveLogin(@Valid @ModelAttribute("userBean")Login userBean,BindingResult result,Model m)
	{
		System.out.println("in login controler");
		if (result.hasErrors())
		{
			m.addAttribute("user", userBean);
			return "login";
		}
		else
		{
			
			m.addAttribute("user", userBean);
			
			int p=loginService.checkLogin(userBean);
			if(p>0) {
			         
			 return "home";
			}else {
				return "login";
			}
		}
		
		
		
		}
	}

