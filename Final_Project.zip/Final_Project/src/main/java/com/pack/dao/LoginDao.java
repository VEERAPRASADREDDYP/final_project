package com.pack.dao;


import org.hibernate.query.Query;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.Login;
public class LoginDao {
	@Autowired
	private	 SessionFactory sessionFactory;
	 
	/*public void addUser(Login userBean) {
		   
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  session.save(userBean);
		  tx.commit();
		  session.close(); 
	  }*/
	
	public int checkLogin(Login userBean) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		int p=0;
		String query="from Login";
		Query q=session.createQuery(query);	
		List<Login> list=q.getResultList();
		for (Iterator<Login> itr=list.iterator();itr.hasNext();)
		{	
		for(Login u:list) {
			Login obj=(Login)itr.next();
			String u1=obj.getPassword();
			String u2=obj.getUserName();
			
			
		if((u2.equals(userBean.getUserName())) && (u1.equals(userBean.getPassword()))) {
			
			 p=1;
		}
		}	
		}
		session.close();
		return p;
		
	}
}
