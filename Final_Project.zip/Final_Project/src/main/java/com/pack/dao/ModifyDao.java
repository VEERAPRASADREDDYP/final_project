package com.pack.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.pack.model.Customer;

public class ModifyDao {
	@Autowired
	private	 SessionFactory sessionFactory;
	public int addUser(Customer customerBean) {
		   
		 Session session=sessionFactory.openSession();
		  Transaction tx=session.beginTransaction();
		  session.update(customerBean);
		  tx.commit();
		  session.close(); 
		  return 1;
}
}
